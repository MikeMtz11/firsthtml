# In-N-Out burger webiste design

In the [assets] folder there contains all images and icons you will need to recreate the main In-N-Out homepage.

Please make your own index.html and style.css files in this folder and start replicating the In-N-Out homepage

[in-n-out](https://www.in-n-out.com/)

You are only responsible for recreating the main home page as shown on the In-N-Out site. 

## Tip
Please pay attention to the folder calles "assets", you will have to make sure you are pulling your images with the correct path.